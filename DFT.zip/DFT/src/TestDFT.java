 
/**
 * CS828-Computer Audio
 * Assignment 2
 * Akshyata (200394002)
 * A Program to implement Discrete Fourier Transform
 */


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;



public class TestDFT {
	public static void main(String args[]) throws IOException {
		 
		int N = 512;
		double T = 5.0;
		double fk;
		
		//extracting values values from values.txt
		BufferedReader in = new BufferedReader(new FileReader("C:\\Users\\akshyata\\Downloads\\values.txt"));
		List<String> readFile = new ArrayList<String>();
		String line;
		while(( line = in.readLine()) != null) {
			readFile.add(line);
		}
		String tempValues[] = new String[readFile.size()];
		tempValues= readFile.toArray(tempValues);
		
		double values[] = new double[tempValues.length];
		for(int i=0;i<tempValues.length;i++) {
			values[i]= Double.parseDouble(tempValues[i]);
			values[i] = Math.pow(10,values[i]/20); //formula to convert db values to values
		}
		//assigning values at even and odd positions
		double fdata[] = new double[2* N];
		for (int i = 0; i < N-1; ++i) {
			fdata[2 * i] = values[i];
			fdata[2 * i + 1] = 0.0;
		}
		
		double X[] = Fourier.discreteFT(fdata, N);
		//for printing real and imaginary frequency parts alternatively
		for (int k = 0; k < N; ++k) {
			fk = k / T;
			System.out.println("f["+k+"] = "+fk+" Real["+k+"] = "+X[2*k]+ " Imag["+k+"] = "+X[2*k + 1]) ;
		}
	}
}
