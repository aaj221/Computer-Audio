/**
 * CS828-Computer Audio
 * Assignment 2
 * Akshyata (200394002)
 * A Program to implement Discrete Fourier Transform
 */

public class Fourier {
	public static double[] discreteFT(double[]fdata, int N){
		double X[] = new double[2*N];
		double omega;
		int ki, kr, n;
	
		omega = 2.0*Math.PI/N;

		for(int k=0; k<N; k++) {
			//Assigning initial values to real and imaginary parts 
			kr = 2*k;
			ki = 2*k + 1;
			X[kr] = 0.0;
			X[ki] = 0.0;
			// DFT calculation
			for(n=0; n<N; ++n) {
				X[kr] += fdata[2*n]*Math.cos(omega*n*k) + fdata[2*n+1]*Math.sin(omega*n*k);
				X[ki] += -fdata[2*n]*Math.sin(omega*n*k) + fdata[2*n+1]*Math.cos(omega*n*k);
			}
		}
		
		for(int k=0; k<N; ++k) {
			X[2*k] /= N;
			X[2*k + 1] /= N;
		}
		
		return X;
	}
}

